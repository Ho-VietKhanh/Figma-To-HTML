﻿/*
Câu 1:Với tham số vào là Masv, Lấy ra thông tin Masv, HoTen, TenMon của những sinh viên có giới tính là Nam
Câu 2:Với đầu vào là MSSV, tham số ra là điểm trung bình mà sinh viên đó đã học ở tất cả các môn.
Điểm Trung Bình được tính = Tổng Điểm / (Tổng Số Tín Chỉ *4), của tất cả các môn.
*/
USE QL_SinhVien_GK

-- CÂU 1: Với tham số vào là Masv, Lấy ra thông tin Masv, HoTen, TenMon của những sinh viên có giới tính là Nam
IF OBJECT_ID ('CAU_1', 'P') IS NOT NULL
	DROP PROCEDURE CAU_1 
GO
CREATE PROCEDURE CAU_1 (@MASV NVARCHAR(200))
AS
	BEGIN
		SELECT SV.[MSSV], SV.[HOSV], SV.[TENSV], DMMH.[TENMON]
		FROM [dbo].[SINHVIEN] AS [SV], [dbo].[KETQUATHI] AS [KQT], [dbo].[DMMONHOC] AS [DMMH]
		WHERE SV.[MSSV] = KQT.[MSSV] AND KQT.[MAMH] = DMMH.[MAMH] AND SV.[PHAI] = N'NAM' AND SV.[MSSV] = @MASV
	END 
GO

-----------------THỰC THI----------------
EXECUTE CAU_1 @MASV ='SV002'


--CÂU 2: Với đầu vào là MSSV, tham số ra là điểm trung bình mà sinh viên đó đã học ở tất cả các môn.
--Điểm Trung Bình được tính = Tổng Điểm / (Tổng Số Tín Chỉ *4), của tất cả các môn.
IF OBJECT_ID ('CAU_2', 'P') IS NOT NULL
    DROP PROCEDURE CAU_2;
GO 

CREATE PROCEDURE CAU_2 (@MSSV NVARCHAR(50), @DIEMTB DECIMAL(10,2) OUTPUT)
AS
BEGIN
    DECLARE @TongDiem DECIMAL(10,2), @TongTinChi INT;
    
    SELECT 
        @TongDiem = SUM(KQT.[DIEM]),
        @TongTinChi = SUM(DMMH.[SOTINCHI])
    FROM [dbo].[SINHVIEN] AS SV, [dbo].[KETQUATHI] AS KQT, [dbo].[DMMONHOC] AS DMMH
    WHERE SV.[MSSV] = @MSSV AND SV.[MSSV] = KQT.[MSSV] AND DMMH.[MAMH] = KQT.[MAMH]

    IF @TongTinChi = 0
        SET @DIEMTB = NULL;
    ELSE
        SET @DIEMTB = @TongDiem / (@TongTinChi * 4);
END
GO

-----
DECLARE @TONGDIEM DECIMAL(10,2)
EXECUTE CAU_2 @MSSV = 'SV002', @DIEMTB = @TONGDIEM OUTPUT
PRINT N'DIEM TB: ' + CAST (@DIEMTB AS CHAR (5))

